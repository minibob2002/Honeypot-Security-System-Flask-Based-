import numpy as np

def shannon_rate(cqi, x, Wb=180e3, p_lin=10.0, noise_lin=1.0):
    """
    Compute per-UE instantaneous rate R_u given:
    - cqi: (U,B) linear "SNR-like" gains (before power scaling)
    - x:   (U,B) binary allocation (one UE per RB)
    - Wb:  per-RB bandwidth (Hz), default 180 kHz (LTE/NR PRB scale)
    - p_lin: transmit power scaling (linear)
    - noise_lin: noise power (linear)
    Assumes orthogonal RBs (no intra-cell interference).
    Returns R: (U,) vector of rates in bits/s for this slot.
    """
    U, B = cqi.shape
    snr = (p_lin * cqi) / (noise_lin + 1e-9)
    cap = Wb * np.log2(1.0 + snr)          # (U,B)
    served = cap * x                        # zero out unassigned RBs
    return served.sum(axis=1)               # per-UE sum


def jain_fairness(rates):
    r = np.array(rates)
    s1 = (r.sum()) ** 2
    s2 = (r**2).sum() + 1e-12
    n = len(r)
    return s1 / (n * s2)


class Simulator:
    def __init__(self, channel, scheduler, U, B, T=1000, gamma=0.01, Wb=180e3, p_lin=10.0, noise_lin=1.0):
        self.channel = channel
        self.scheduler = scheduler
        self.U, self.B = U, B
        self.T = T
        self.gamma = gamma
        self.Wb, self.p_lin, self.noise_lin = Wb, p_lin, noise_lin
        self.avg_rate = np.full(U, 1e-3)  # small start to avoid div-by-zero
        self.history_rates = []           # per-slot sum rate
        self.user_bitloads = np.zeros(U)  # cumulative bits/UE

    def run(self, progress=False):
        for t in range(self.T):
            cqi = self.channel.step()             # (U,B)
            x = self.scheduler.allocate(cqi, self.avg_rate)  # (U,B)
            R = shannon_rate(cqi, x, self.Wb, self.p_lin, self.noise_lin)  # (U,)
            self.user_bitloads += R
            sum_rate = R.sum()
            self.history_rates.append(sum_rate)
            # Update PF moving average
            self.avg_rate = (1 - self.gamma) * self.avg_rate + self.gamma * R
            if progress and (t+1) % max(1, self.T//10) == 0:
                print(f"[{t+1}/{self.T}] Sum-rate: {sum_rate/1e6:.2f} Mbps")
        return np.array(self.history_rates), self.user_bitloads
