import numpy as np

class RoundRobinScheduler:
    def __init__(self, U, B):
        self.U, self.B = U, B
        self.ptr = 0

    def allocate(self, cqi, avg_rate):
        """
        cqi: (U,B) matrix of channel gains (not used here)
        avg_rate: (U,) moving average rate vector (not used)
        Returns x: (U,B) binary allocation matrix, one UE per RB.
        """
        x = np.zeros_like(cqi, dtype=int)
        for b in range(self.B):
            u = (self.ptr + b) % self.U
            x[u, b] = 1
        self.ptr = (self.ptr + self.B) % self.U
        return x


class MaxCQIScheduler:
    def __init__(self, U, B):
        self.U, self.B = U, B

    def allocate(self, cqi, avg_rate):
        x = np.zeros_like(cqi, dtype=int)
        # For each RB, pick UE with max instantaneous CQI
        winners = np.argmax(cqi, axis=0)  # (B,)
        for b, u in enumerate(winners):
            x[u, b] = 1
        return x


class ProportionalFairScheduler:
    def __init__(self, U, B, epsilon=1e-6):
        self.U, self.B = U, B
        self.eps = epsilon

    def allocate(self, cqi, avg_rate):
        """
        PF priority ~ cqi / avg_rate
        cqi: (U,B), avg_rate: (U,)
        """
        prio = cqi / (avg_rate[:, None] + self.eps)  # (U,B)
        winners = np.argmax(prio, axis=0)            # (B,)
        x = np.zeros_like(cqi, dtype=int)
        for b, u in enumerate(winners):
            x[u, b] = 1
        return x
