import numpy as np

class GaussMarkovChannel:
    """
    Simple per-(u,b) Gauss–Markov fading process producing linear-scale SNR-like gains.
    We produce a positive gain by exponentiating a Gaussian (log-normal shadowing flavor).
    """
    def __init__(self, U, B, rho=0.95, mean_db=5.0, std_db=8.0, seed=42):
        self.U, self.B = U, B
        self.rho = rho
        self.rng = np.random.default_rng(seed)
        mu = mean_db
        sigma = std_db
        self.state_db = self.rng.normal(mu, sigma, size=(U, B))

    def step(self):
        eps = self.rng.normal(0.0, 1.0, size=self.state_db.shape)
        self.state_db = self.rho * self.state_db + np.sqrt(1 - self.rho**2) * 8.0 * eps
        # Convert dB to linear gain (approximately SNR before power scaling)
        gain_lin = 10 ** (self.state_db / 10.0)
        return gain_lin  # shape: (U, B)
