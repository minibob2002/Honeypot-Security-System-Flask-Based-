import argparse, os
import numpy as np
import matplotlib.pyplot as plt
from sim.channel import GaussMarkovChannel
from sim.baselines import RoundRobinScheduler, MaxCQIScheduler, ProportionalFairScheduler
from sim.core import Simulator, jain_fairness

def get_scheduler(name, U, B):
    name = name.lower()
    if name in ["rr", "roundrobin", "round-robin"]:
        return RoundRobinScheduler(U,B)
    if name in ["maxcqi", "max-cqi", "cqi"]:
        return MaxCQIScheduler(U,B)
    if name in ["pf", "propfair", "proportional-fair"]:
        return ProportionalFairScheduler(U,B)
    raise ValueError(f"Unknown scheduler: {name}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--U", type=int, default=20, help="Number of UEs")
    ap.add_argument("--B", type=int, default=10, help="Number of RBs")
    ap.add_argument("--T", type=int, default=1000, help="Number of time slots")
    ap.add_argument("--scheduler", type=str, default="pf", help="rr|maxcqi|pf")
    ap.add_argument("--rho", type=float, default=0.95, help="Channel time correlation")
    ap.add_argument("--seed", type=int, default=42, help="Random seed")
    args = ap.parse_args()

    os.makedirs("outputs", exist_ok=True)

    ch = GaussMarkovChannel(args.U, args.B, rho=args.rho, seed=args.seed)
    sched = get_scheduler(args.scheduler, args.U, args.B)
    sim = Simulator(ch, sched, args.U, args.B, T=args.T)

    hist, bitloads = sim.run(progress=True)

    # Metrics
    mean_sumrate = hist.mean()
    fairness = jain_fairness(bitloads)
    p5 = np.percentile(bitloads, 5) / (args.T)   # per-slot avg 5th pct UE
    p50 = np.percentile(bitloads, 50) / (args.T)
    p95 = np.percentile(bitloads, 95) / (args.T)

    print("\n=== Results ===")
    print(f"Scheduler: {args.scheduler}")
    print(f"Avg sum-rate: {mean_sumrate/1e6:.2f} Mbps")
    print(f"Jain fairness: {fairness:.3f}")
    print(f"Per-UE rate percentiles (per-slot): p5={p5/1e6:.2f} Mbps, p50={p50/1e6:.2f} Mbps, p95={p95/1e6:.2f} Mbps")

    # Figure: CDF of per-UE average rate
    per_ue_rate = bitloads / args.T
    xs = np.sort(per_ue_rate/1e6)  # Mbps
    ys = np.linspace(0,1,len(xs),endpoint=False)
    plt.figure()
    plt.plot(xs, ys, drawstyle="steps-post")
    plt.xlabel("Per-UE average rate (Mbps)")
    plt.ylabel("CDF")
    plt.title(f"CDF of UE Rates — {args.scheduler.upper()}")
    out_png = f"outputs/cdf_{args.scheduler}.png"
    plt.savefig(out_png, bbox_inches="tight")
    print(f"Saved figure: {out_png}")

if __name__ == "__main__":
    main()
