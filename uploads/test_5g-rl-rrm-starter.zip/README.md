# 5G Intelligent Resource Allocation (Starter Kit)

This is a minimal simulator to prototype resource allocation policies (baselines today, RL later).
It simulates a single gNB with `B` orthogonal resource blocks (RBs) and `U` users over `T` time slots.

## Contents
- `sim/channel.py` — simple Gauss–Markov channel model per UE×RB
- `sim/baselines.py` — Round-Robin, Max-CQI, and Proportional-Fair schedulers
- `sim/core.py` — network config, scheduling step, metrics
- `run_baseline.py` — run a quick experiment and print metrics
- `requirements.txt` — only numpy & matplotlib for now; PyTorch reserved for later RL

## Quick start
```bash
pip install -r requirements.txt
python run_baseline.py --scheduler pf --U 30 --B 12 --T 2000
```
This will print throughput/fairness metrics and save a CDF figure under `outputs/`.
